---
navigation:
  title: 激光转子
  icon: "synergy:laser_rotor"
  parent: lasers.md
  position: 5
categories:
  - lasers
item_ids:
  - synergy:laser_rotor
---

# 激光转子

使用同一台激光发射器击中转子的各侧面后，它会产出FE。

若有另一台激光发射器击中某一侧面，转子即会重置状态。

右击可旋转方块。

<RecipeFor id="synergy:laser_rotor" />

### 使用激光转子手动产出FE的示例设施

<GameScene zoom="2" interactive={true}>
<ImportStructure src="../templates/base.nbt" pos="1 -1 1"/>

<Block x="5" z="5" id="synergy:laser_rotor" p:enabled="false"/>

<Block x="7" z="5" id="synergy:laser_mirror" p:inverted="false"/>

<BoxAnnotation color="#0095ff" min="7.25 0 5.25" max="7.75 0.5 5.75">
       旋转后，它会将激光引导至激光转子的另一侧面
  </BoxAnnotation>

<Block x="5" z="7" id="synergy:laser_mirror" p:inverted="true"/>

<BoxAnnotation color="#0095ff" min="5.25 0 7.25" max="5.75 0.5 7.75">
       旋转后，它会将激光引导至激光转子的另一侧面
  </BoxAnnotation>

<Block x="3" z="5" id="synergy:laser_mirror" p:inverted="false"/>

<BoxAnnotation color="#0095ff" min="3.25 0 5.25" max="3.75 0.5 5.75">
       旋转后，它会将激光引导至激光转子的另一侧面
  </BoxAnnotation>

<Block x="8" z="5" id="synergy:laser_mirror" p:inverted="false"/>
<Block x="8" z="7" id="synergy:laser_mirror" p:inverted="true"/>

<Block x="5" z="8" id="synergy:laser_mirror" p:inverted="true"/>
<Block x="3" z="8" id="synergy:laser_mirror" p:inverted="false"/>

<Block x="5" z="3" id="synergy:laser_mirror" p:inverted="false"/>

<Block x="2" z="3" id="synergy:laser_mirror" p:inverted="true"/>
<Block x="2" z="5" id="synergy:laser_mirror" p:inverted="false"/>

<Block x="7" z="1" id="synergy:solar_panel" p:north="false" p:south="false" p:east="false" p:west="false" p:enabled="true"/>

  <Block x="7" z="2" id="synergy:laser_machine_gun" p:facing="south" p:enabled="true"/>

  <Block x="8" z="2" id="minecraft:lever" p:face="floor" p:powered="true"/>

</GameScene>
